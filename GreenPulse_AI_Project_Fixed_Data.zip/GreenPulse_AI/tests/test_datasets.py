from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def test_water_dataset_has_required_columns():
    df = pd.read_csv(ROOT / "data" / "water_usage_sample.csv")
    assert {"date", "litres"}.issubset(df.columns)
    assert len(df) >= 5
    assert pd.to_numeric(df["litres"], errors="coerce").notna().all()

def test_waste_dataset_has_multiple_categories():
    df = pd.read_csv(ROOT / "data" / "waste_training_sample.csv")
    assert {"description", "category"}.issubset(df.columns)
    assert df["category"].nunique() >= 4
    assert df["description"].notna().all()
