# Camera and code scanning feature

The dashboard now has a **Camera & code scan** tab.

## QR codes and barcodes
Install the code reader:
```cmd
python -m pip install -r requirements-scan.txt
```
Then choose **Read a QR code / barcode**, take a photo or upload an image, and click **Scan code in image**.

This decodes the code contents only. To connect a product barcode to composition or recycling instructions, a product database/API would be needed.

## Image-based waste category suggestion
This feature uses the optional CLIP vision model. It can download a large machine-learning model the first time it runs and requires internet access on first use.
```cmd
python -m pip install -r requirements-vision.txt
```
Restart Streamlit after installation:
```cmd
python -m streamlit run app.py
```
Open the **Camera & code scan** tab, choose **Identify waste from an image**, take a photo/upload one, and click **Identify waste from image**.

## Important limitations
- Image predictions are best-effort suggestions, not guaranteed identifications.
- Model scores are not validated probabilities.
- Product codes do not automatically reveal material composition without a matching product database.
- Verify disposal instructions with local municipal guidance.
